//function Ant(crslId) {

	//let id = document.getElementById(crslId);
	//if(id) {
	//	this.crslRoot = id
	//}
	//else {
	//	this.crslRoot = document.querySelector('.ant-carousel')
	//};

	// Carousel objects
	//this.crslList = this.crslRoot.querySelector('.ant-carousel-list');
	//this.crslElements = this.crslList.querySelectorAll('.ant-carousel-element');
	//this.crslElemFirst = this.crslList.querySelector('.ant-carousel-element');
	//this.leftArrow = this.crslRoot.querySelector('div.ant-carousel-arrow-left');
	//this.rightArrow = this.crslRoot.querySelector('div.ant-carousel-arrow-right');
	//this.indicatorDots = this.crslRoot.querySelector('div.ant-carousel-dots');
